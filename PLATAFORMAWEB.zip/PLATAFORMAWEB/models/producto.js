const mongoose = require("mongoose");

const productoSchema = new mongoose.Schema(
  {
    nombre: String,
    descripcion: String,
    categoria: String,
    precio: Number,
    disponibilidad_en_inventario: Boolean,
    proveedor: String,
    imagen: String,
  },
  { collection: "PRODUCTOS", versionKey: false }
);

module.exports = mongoose.model("Producto", productoSchema);
