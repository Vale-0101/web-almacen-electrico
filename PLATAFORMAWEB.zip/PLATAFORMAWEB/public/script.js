document.addEventListener("DOMContentLoaded", () => {
  const crearForm = document.getElementById("crear-form");
  const editarForm = document.getElementById("editar-form");
  const eliminarForm = document.getElementById("eliminar-form");
  const buscarBtn = document.getElementById("buscar-producto");

  async function fetchProductos() {
    const response = await fetch("/productos");
    const productos = await response.json();
    const productosLista = document.getElementById("productos-lista");
    productosLista.innerHTML = "";
    productos.forEach((producto) => {
      const div = document.createElement("div");
      let disponibilidad = producto.disponibilidad_en_inventario;
      let respuesta
      if (disponibilidad === true) {
        respuesta = 'si';
      } else {
        respuesta = 'no';
      }
      div.innerHTML = `
                <h3>${producto.nombre}</h3>
                <p>${producto.descripcion}</p>
                <p>Categoría: ${producto.categoria}</p>
                <p>Precio: ${producto.precio}</p>
                <p>Proveedor: ${producto.proveedor}</p>
                <p>Disponible en Inventario: ${respuesta}</p>
                <img src="${producto.imagen}" alt="${producto.nombre}" style="max-width: 100px;">
            `;
      productosLista.appendChild(div);
    });
  }

  if (document.getElementById("productos-lista")) {
    fetchProductos();
  }

  if (crearForm) {
    crearForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const productoData = {
        nombre: document.getElementById("crear-nombre").value,
        descripcion: document.getElementById("crear-descripcion").value,
        categoria: document.getElementById("crear-categoria").value,
        precio: parseFloat(document.getElementById("crear-precio").value),
        disponibilidad_en_inventario: document.getElementById(
          "crear-disponibilidad_en_inventario"
        ).checked,
        proveedor: document.getElementById("crear-proveedor").value,
        imagen: document.getElementById("crear-imagen").value,
      };
      try {
        const response = await fetch("/productos", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(productoData),
        });
        if (!response.ok) throw new Error("Error al crear el producto");
        const result = await response.json();
        document.getElementById("crear-message").textContent =
          "Producto creado exitosamente";
        crearForm.reset();
        fetchProductos();
      } catch (error) {
        document.getElementById("crear-message").textContent = error.message;
      }
    });
  }

  if (buscarBtn) {
    buscarBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      const id = document.getElementById("buscar-id").value;
      try {
        const response = await fetch(`/productos/${id}`);
        if (!response.ok) throw new Error("Error al buscar el producto");
        const producto = await response.json();
        if (!producto) throw new Error("Producto no encontrado");

        document.getElementById("editar-id").value = producto._id;
        document.getElementById("editar-nombre").value = producto.nombre;
        document.getElementById("editar-descripcion").value =
          producto.descripcion;
        document.getElementById("editar-categoria").value = producto.categoria;
        document.getElementById("editar-precio").value = producto.precio;
        document.getElementById("editar-disponibilidad_en_inventario").checked =
          producto.disponibilidad_en_inventario;
        document.getElementById("editar-proveedor").value = producto.proveedor;
        document.getElementById("editar-imagen").value = producto.imagen;

        document.getElementById("editar-message").textContent =
          "Producto encontrado";
      } catch (error) {
        document.getElementById("editar-message").textContent = error.message;
      }
    });
  }

  if (editarForm) {
    editarForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const id = document.getElementById("editar-id").value;
      const productoData = {
        nombre: document.getElementById("editar-nombre").value,
        descripcion: document.getElementById("editar-descripcion").value,
        categoria: document.getElementById("editar-categoria").value,
        precio: parseFloat(document.getElementById("editar-precio").value),
        disponibilidad_en_inventario: document.getElementById(
          "editar-disponibilidad_en_inventario"
        ).checked,
        proveedor: document.getElementById("editar-proveedor").value,
        imagen: document.getElementById("editar-imagen").value,
      };
      try {
        const response = await fetch(`/productos/${id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(productoData),
        });
        if (!response.ok) throw new Error("Error al actualizar el producto");
        const result = await response.json();
        document.getElementById("editar-message").textContent =
          "Producto actualizado exitosamente";
        editarForm.reset();
        fetchProductos();
      } catch (error) {
        document.getElementById("editar-message").textContent = error.message;
      }
    });
  }

  if (eliminarForm) {
    eliminarForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const id = document.getElementById("eliminar-id").value;
      try {
        const response = await fetch(`/productos/${id}`, {
          method: "DELETE",
        });
        if (!response.ok) throw new Error("Error al eliminar el producto");
        const result = await response.json();
        document.getElementById("eliminar-message").textContent =
          "Producto eliminado exitosamente";
        eliminarForm.reset();
        fetchProductos();
      } catch (error) {
        document.getElementById("eliminar-message").textContent = error.message;
      }
    });
  }
});
