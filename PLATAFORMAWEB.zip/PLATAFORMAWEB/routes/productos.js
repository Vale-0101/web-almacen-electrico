const express = require("express");
const router = express.Router();
const Producto = require("../models/producto");
const mongoose = require('mongoose');

// Obtener todos los productos
router.get("/", async (req, res) => {
  try {
    const productos = await Producto.find();
    res.json(productos);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo producto
router.post("/", async (req, res) => {
  const nuevoProducto = new Producto(req.body);
  try {
    const productoGuardado = await nuevoProducto.save();
    res.status(201).json(productoGuardado);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Obtener un producto por ID
router.get("/:id", getProducto, (req, res) => {
  res.json(res.producto);
});

// Actualizar un producto por ID
router.put("/:id", getProducto, async (req, res) => {
  Object.assign(res.producto, req.body);
  try {
    const productoActualizado = await res.producto.save();
    res.json(productoActualizado);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Eliminar un producto por ID
router.delete("/:id", getProducto, async (req, res) => {
  try {
    await res.producto.deleteOne();
    res.json({ message: "Producto eliminado" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Middleware para obtener un producto por ID
async function getProducto(req, res, next) {
  let producto;
  try {
    // Verificar que el id sea válido
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: "ID de producto no válido" });
    }

    producto = await Producto.findById(req.params.id);
    if (producto == null) {
      return res
        .status(404)
        .json({ message: "No se puede encontrar el producto" });
    }
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
  res.producto = producto;
  next();
}

module.exports = router;
